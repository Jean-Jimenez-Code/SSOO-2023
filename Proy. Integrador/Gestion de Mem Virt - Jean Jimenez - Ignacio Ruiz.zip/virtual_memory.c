#include "virtual_memory.h"

void assignPage(VirtualMemory *virtualMemory, int pageNumber)
{
    if (!virtualMemory->pages[pageNumber].isAssigned)
    {
        virtualMemory->pages[pageNumber].isAssigned = 1;
        printf("La página %d ha sido asignada.\n", pageNumber);
    }
    else
    {
        printf("La página %d ya está asignada.\n", pageNumber);
    }
}

void freePage(VirtualMemory *virtualMemory, int pageNumber)
{
    if (virtualMemory->pages[pageNumber].isAssigned)
    {
        virtualMemory->pages[pageNumber].isAssigned = 0;
        printf("La página %d ha sido liberada.\n", pageNumber);
    }
}

void replacePageFIFO(VirtualMemory *virtualMemory, double *replaceTimes)
{
    int pageIndex = virtualMemory->fifoNextIndex;
    if (pageIndex==NUM_PAGES-1)
    {
        printf("Reemplazando la página %d por %d.\n", pageIndex, 0);
    }else{
        printf("Reemplazando la página %d por %d.\n", pageIndex, pageIndex+1);
    }

    clock_t start = clock(); 
    freePage(virtualMemory, pageIndex);
    clock_t end = clock(); 

    double time_spent = ((double) (end - start)) / CLOCKS_PER_SEC; 
    printf("Tiempo empleado en reemplazar la página: %f segundos.\n", time_spent);
    replaceTimes[pageIndex] = time_spent; 

    virtualMemory->fifoNextIndex = (virtualMemory->fifoNextIndex + 1) % NUM_PAGES;
    printf("La próxima página a reemplazar es %d.\n", virtualMemory->fifoNextIndex);
}

void loadFileIntoMemory(FILE *file, VirtualMemory *virtualMemory)
{
    for (int i = 0; i < NUM_PAGES; ++i)
    {
        virtualMemory->pages[i].pageNumber = i;
        fread(virtualMemory->pages[i].data, sizeof(char), PAGE_SIZE, file);
    }
}

void printPage(Page *page)
{
    printf("Número de página: %d\n", page->pageNumber);
    printf("Datos: %s\n", page->data);
}

void checkPageAvailability(VirtualMemory *virtualMemory, int pageNumber)
{
    if (pageNumber < 0 || pageNumber >= NUM_PAGES)
    {
        printf("Error: La página %d no existe.\n", pageNumber);
        exit(1); 
    }

    if (!virtualMemory->pages[pageNumber].isAssigned)
    {
        printf("Error: La página %d no está asignada.\n", pageNumber);
        exit(1); 
    }
}

void checkDataOverflow(FILE *file)
{
    int nextChar = fgetc(file);

    if (nextChar != EOF)
    {
        printf("Hay un exceso de datos, es recomendable agregar una página.\n");
    }

    ungetc(nextChar, file);
}

void accessPage(VirtualMemory *virtualMemory, int pageNumber)
{
    virtualMemory->pages[pageNumber].lastAccessTime = clock();
}

void replacePageLRU(VirtualMemory *virtualMemory, double *replaceTimes)
{
    int lruIndex = 0;
    for (int i = 1; i < NUM_PAGES; ++i)
    {
        if (virtualMemory->pages[i].lastAccessTime < virtualMemory->pages[lruIndex].lastAccessTime)
        {
            lruIndex = i;
        }
    }

    int replacedBy = (lruIndex == 0) ? 0 : lruIndex - 1;
    if (lruIndex == 0) {
        printf("Manteniendo la página %d.\n", lruIndex);
    } else {
        printf("Reemplazando la página %d con la página %d.\n", lruIndex, replacedBy);
    }

    clock_t start = clock(); 
    freePage(virtualMemory, lruIndex);
    clock_t end = clock(); 

    double time_spent = ((double) (end - start)) / CLOCKS_PER_SEC; 
    printf("Tiempo empleado en reemplazar la página: %f segundos.\n", time_spent);
    replaceTimes[lruIndex] = time_spent; 

    assignPage(virtualMemory, lruIndex);
    accessPage(virtualMemory, lruIndex);
}

void assignRandomAccessCounts(int *accessCounts)
{
    for (int i = 0; i < NUM_PAGES; ++i)
    {
        accessCounts[i] = rand() % 20; // Asigna un número aleatorio a accessCounts[i]
    }
}

void replacePageMFU(VirtualMemory *virtualMemory, double *replaceTimes, int *accessCounts)
{
    int mfuIndex = 0;
    for (int i = 1; i < NUM_PAGES; ++i)
    {
        if (accessCounts[i] > accessCounts[mfuIndex])
        {
            mfuIndex = i;
        }
    }

    printf("Reemplazando la página más usada %d con frecuencia %d.\n", mfuIndex, accessCounts[mfuIndex]);

    clock_t start = clock(); 
    freePage(virtualMemory, mfuIndex);
    clock_t end = clock(); 

    double time_spent = ((double) (end - start)) / CLOCKS_PER_SEC; 
    printf("Tiempo empleado en reemplazar la página: %f segundos.\n", time_spent);
    replaceTimes[mfuIndex] = time_spent; 

    assignPage(virtualMemory, mfuIndex);
    accessPage(virtualMemory, mfuIndex); 

    accessCounts[mfuIndex] = 0; 
}

void replacePageMRU(VirtualMemory *virtualMemory, double *replaceTimes)
{
    static int mruIndex = -1;

    if (mruIndex == -1) {
        mruIndex = 0;
        printf("Manteniendo la página %d.\n", mruIndex);
    } else {
        printf("Reemplazando la página %d con la página %d.\n", mruIndex, (mruIndex + 1) % NUM_PAGES);
        mruIndex = (mruIndex + 1) % NUM_PAGES;
    }

    clock_t start = clock(); 
    freePage(virtualMemory, mruIndex);
    clock_t end = clock(); 

    double time_spent = ((double) (end - start)) / CLOCKS_PER_SEC; 
    printf("Tiempo empleado en reemplazar la página: %f segundos.\n", time_spent);
    replaceTimes[mruIndex] = time_spent; 

    assignPage(virtualMemory, mruIndex);
    accessPage(virtualMemory, mruIndex); 
}


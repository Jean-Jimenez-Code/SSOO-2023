#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define PAGE_SIZE 3
#define NUM_PAGES 4


// Estructura de una página
typedef struct
{
    int pageNumber;
    char data[PAGE_SIZE];
    int isAssigned;
    clock_t lastAccessTime; // Agrega este campo
} Page;


typedef struct
{
    Page pages[NUM_PAGES];
    int fifoNextIndex;
} VirtualMemory;

void assignPage(VirtualMemory *virtualMemory, int pageNumber);
void freePage(VirtualMemory *virtualMemory, int pageNumber);
void replacePageFIFO(VirtualMemory *virtualMemory, double *replaceTimes);
void loadFileIntoMemory(FILE *file, VirtualMemory *virtualMemory);
void printPage(Page *page);
void checkPageAvailability(VirtualMemory *virtualMemory, int pageNumber);
void checkDataOverflow(FILE *file);
void accessPage(VirtualMemory *virtualMemory, int pageNumber);
void replacePageLRU(VirtualMemory *virtualMemory, double *replaceTimes);
void assignRandomAccessCounts(int *accessCounts);
void replacePageMFU(VirtualMemory *virtualMemory, double *replaceTimes, int *accessCounts);



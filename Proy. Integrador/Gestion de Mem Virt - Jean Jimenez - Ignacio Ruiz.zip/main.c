#include "virtual_memory.h"

int main()
{

    FILE *file = fopen("datos.txt", "r");

    if (file == NULL)
    {
        perror("Error al abrir el archivo");
        return 1;
    }


    VirtualMemory virtualMemory;
    virtualMemory.fifoNextIndex = 0; 


    loadFileIntoMemory(file, &virtualMemory);

    for (int i = 0; i < NUM_PAGES; ++i)
    {
        assignPage(&virtualMemory, i);
        accessPage(&virtualMemory, i); 
    }

    for (int i = 0; i < NUM_PAGES; ++i)
    {
        checkPageAvailability(&virtualMemory, i); 
    }

    checkDataOverflow(file);


    for (int i = 0; i < NUM_PAGES; ++i)
    {
        printf("\nContenido de la Página %d:\n", virtualMemory.pages[i].pageNumber);
        printPage(&virtualMemory.pages[i]);
    }

    double replaceTimes[NUM_PAGES] = {0}; // Inicializa los tiempos de reemplazo a 0

    int opcion;
    int minTimeIndex;
    while(1) {
        printf("\nElige una opción:\n");
        printf("1. Reemplazo por FIFO\n");
        printf("2. Reemplazo por LRU\n");
        printf("3. Reemplazo por MFU\n");
        printf("4. Reemplazo por MRU\n");
        printf("5. Salir\n");
        printf("\nIntroduce el número de tu opción: ");
        scanf("%d", &opcion);

        switch(opcion) {
            case 1:
                printf("Has seleccionado reemplazo por FIFO.\n");
                for (int i = 0; i < NUM_PAGES; ++i)
                {
                    replacePageFIFO(&virtualMemory, replaceTimes);
                }
                minTimeIndex = 0;
                for (int i = 1; i < NUM_PAGES; ++i)
                {
                    if (replaceTimes[i] < replaceTimes[minTimeIndex])
                    {
                        minTimeIndex = i;
                    }
                }
                printf("La página que tomó menos tiempo para reemplazar fue la página %d, con un tiempo de %f segundos.\n", minTimeIndex, replaceTimes[minTimeIndex]);
                break;
            case 2:
                printf("Has seleccionado reemplazo por LRU.\n");
                for (int i = 0; i < NUM_PAGES; ++i)
                {
                    replacePageLRU(&virtualMemory, replaceTimes);
                }
                minTimeIndex = 0;
                for (int i = 1; i < NUM_PAGES; ++i)
                {
                    if (replaceTimes[i] < replaceTimes[minTimeIndex])
                    {
                        minTimeIndex = i;
                    }
                }
                printf("La página que tomó menos tiempo para reemplazar fue la página %d, con un tiempo de %f segundos.\n", minTimeIndex, replaceTimes[minTimeIndex]);
                break;
            case 3:
                printf("Has seleccionado reemplazo por MFU.\n");
                    int accessCounts[NUM_PAGES]; // Crea un array para almacenar los conteos de acceso

                    assignRandomAccessCounts(accessCounts); // Asigna una cantidad aleatoria de accesos a cada página

                    double replaceTimes[NUM_PAGES]; 

                    for (int i = 0; i < NUM_PAGES; ++i)
                    {
                        replacePageMFU(&virtualMemory, replaceTimes, accessCounts);
                    }
                minTimeIndex = 0;
                for (int i = 1; i < NUM_PAGES; ++i)
                {
                    if (replaceTimes[i] < replaceTimes[minTimeIndex])
                    {
                        minTimeIndex = i;
                    }
                }
          printf("La página que tomó menos tiempo para reemplazar fue la página %d, con un tiempo de %f segundos.\n", minTimeIndex, replaceTimes[minTimeIndex]);
                break;
            case 4:
                printf("Has seleccionado reemplazo por MRU.\n");
                for (int i = 0; i < NUM_PAGES; ++i)
                {
                    replacePageMRU(&virtualMemory, replaceTimes);
                }
                break;
                minTimeIndex = 0;
                for (int i = 1; i < NUM_PAGES; ++i)
                {
                    if (replaceTimes[i] < replaceTimes[minTimeIndex])
                    {
                        minTimeIndex = i;
                    }
                }
                printf("La página que tomó menos tiempo para reemplazar fue la página %d, con un tiempo de %f segundos.\n", minTimeIndex, replaceTimes[minTimeIndex]);
            case 5:
                printf("Has seleccionado salir. Adiós!\n");
                return 0;
            default:
                printf("Opción no válida. Por favor, elige una opción del 1 al 5.\n");
        }
    }

    fclose(file);

    return 0;
}
